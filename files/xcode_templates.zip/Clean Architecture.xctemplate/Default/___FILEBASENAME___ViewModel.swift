//___FILEHEADER___

struct ___VARIABLE_productName___ViewModel {
    let navigator: ___VARIABLE_productName___NavigatorType
    let useCase: ___VARIABLE_productName___UseCaseType
}

// MARK: - ViewModelType
extension ___VARIABLE_productName___ViewModel: ViewModelType {
    struct Input {
        
    }
    
    struct Output {
        
    }
    
    func transform(_ input: Input) -> Output {
        return Output()
    }
}
