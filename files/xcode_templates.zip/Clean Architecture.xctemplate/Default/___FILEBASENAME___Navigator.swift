//___FILEHEADER___

import UIKit

protocol ___VARIABLE_productName___NavigatorType {
    
}

struct ___VARIABLE_productName___Navigator: ___VARIABLE_productName___NavigatorType {
    unowned let assembler: Assembler
    unowned let navigationController: UINavigationController
}
