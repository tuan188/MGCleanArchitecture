//___FILEHEADER___

@testable import ___PROJECTNAME___
import RxSwift

final class ___VARIABLE_productName___UseCaseMock: ___VARIABLE_productName___UseCaseType {
    
}
