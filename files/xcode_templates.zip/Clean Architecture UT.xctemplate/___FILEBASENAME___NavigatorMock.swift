//___FILEHEADER___

@testable import ___PROJECTNAME___

final class ___VARIABLE_productName___NavigatorMock: ___VARIABLE_productName___NavigatorType {
    
}
