//___FILEHEADER___

import RxSwift

protocol AppUseCaseType {
    
}

struct AppUseCase: AppUseCaseType {

}
