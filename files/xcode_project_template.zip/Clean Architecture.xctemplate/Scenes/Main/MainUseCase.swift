//___FILEHEADER___

protocol MainUseCaseType {

}

struct MainUseCase: MainUseCaseType {

}
