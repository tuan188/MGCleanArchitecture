//___FILEHEADER___

import UIKit

extension Storyboards {
    static let main = UIStoryboard(name: "Main", bundle: nil)
}

