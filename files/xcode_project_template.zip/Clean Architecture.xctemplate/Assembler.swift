//___FILEHEADER___

protocol Assembler: AnyObject,
                    MainAssembler,
                    AppAssembler,
                    GatewaysAssembler {
    
}

final class DefaultAssembler: Assembler {
    
}
