//___FILEHEADER___

import UIKit

protocol GatewaysAssembler {

}

extension GatewaysAssembler where Self: DefaultAssembler {

}
